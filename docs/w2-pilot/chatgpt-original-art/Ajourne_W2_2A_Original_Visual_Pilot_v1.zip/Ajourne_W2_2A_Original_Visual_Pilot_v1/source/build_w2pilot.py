from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
from pathlib import Path
import json, zipfile, hashlib, math
ROOT=Path('/mnt/data/Ajourne_W2_2A_Original_Visual_Pilot_v1');(ROOT/'assets').mkdir(parents=True,exist_ok=True); (ROOT/'source').mkdir(exist_ok=True)
SRC=Image.open('/mnt/data/a_clean_transparent_background_illustration_compos.png').convert('RGBA')
W,H=1400,940
PLUM='#51304C';MUTED='#6B5B68'; GOLD='#AB812D'; SAGE='#4F816B'; ORCHID='#8964A4'; ROSE='#B47752'
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'; BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'; SERIF='/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'; SERIFB='/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'
def font(size,bold=False,serif=False):return ImageFont.truetype((SERIFB if bold else SERIF) if serif else (BOLD if bold else FONT),size)
def rgba(hex,a=255):return tuple(int(hex[i:i+2],16) for i in (1,3,5))+(a,)
def text(d,xy,msg,size=26,color=PLUM,bold=False,serif=False,anchor=None):d.text(xy,msg,font=font(size,bold,serif),fill=color,anchor=anchor)
def line(d,coords,color,width=4):d.line(coords,fill=color,width=width,joint='curve')
def dot(d,x,y,r,color,outline=None,width=2): d.ellipse((x-r,y-r,x+r,y+r),fill=color,outline=outline,width=width)
def rr(d,b,r,fill,outline=None,width=2):d.rounded_rectangle(b,radius=r,fill=fill,outline=outline,width=width)
def bar_header(img,chapter,title,subtitle):
 d=ImageDraw.Draw(img);text(d,(75,40),chapter,23,ROSE,True);text(d,(75,88),title,46,PLUM,False,True);text(d,(75,158),subtitle,21,MUTED)
def art_crop(crop,box,opacity=.82):
 c=SRC.crop(crop).copy();c.thumbnail((box[2]-box[0],box[3]-box[1]),Image.Resampling.LANCZOS)
 c=ImageEnhance.Color(c).enhance(.60);a=c.getchannel('A').point(lambda q:int(q*opacity) if q>36 else 0);c.putalpha(a)
 return c
def put_art(img,crop,box,opacity=.82):
 c=art_crop(crop,box,opacity);x=(box[0]+box[2]-c.width)//2;y=(box[1]+box[3]-c.height)//2;img.alpha_composite(c,(x,y))
def pill(d,b,fill,txt,tcol=PLUM,sz=23):rr(d,b,18,rgba(fill,36),rgba(fill,110),2);text(d,((b[0]+b[2])//2,(b[1]+b[3])//2),txt,sz,tcol,True,anchor='mm')
def arrow(d,x1,y,x2,color,width=5):
 line(d,[(x1,y),(x2,y)],color,width);line(d,[(x2-12,y-10),(x2,y),(x2-12,y+10)],color,width)
# Keyboard is derived from named MIDI note order C4 (60) to G4 (67), black-key grouping 2+3.
KEYS=[('C4',60,0),('D4',62,1),('E4',64,2),('F4',65,3),('G4',67,4)];BLACK=[('C♯4',61,.72),('D♯4',63,1.72),('F♯4',66,3.72)]
def piano(d,x,y,white_width=112,white_height=210,selected=(),accent=GOLD):
 white_height=int(white_height);n=len(KEYS)
 for nme,m,k in KEYS:
  bx=(x+k*white_width,y,x+(k+1)*white_width,y+white_height)
  active=m in selected
  rr(d,bx,7,rgba('#FFF9ED',252) if not active else rgba(accent,65),rgba('#8D7D84',215),2)
  text(d,(int(x+(k+.5)*white_width),int(y+white_height-25)),nme,18,PLUM if not active else accent,active,anchor='mm')
 for nme,m,k in BLACK:
  bw=int(white_width*.58); bx=int(x+k*white_width); by=y
  rr(d,(bx,by,bx+bw,by+int(white_height*.56)),5,rgba('#433745'),rgba('#433745'),2)
  if m in selected:
   rr(d,(bx+3,by+3,bx+bw-3,by+int(white_height*.56)-4),4,rgba(accent,240))
   text(d,(bx+bw//2,by+int(white_height*.56)-24),nme,14,'#FFFFFF',True,anchor='mm')
def flowline(d,y,start,end,midi,label,color,shape):
 # separated rails with exact start/end time, no audio UI
 text(d,(start-75,y),label,23,PLUM,True,anchor='rm')
 rr(d,(start,y-19,end,y+19),18,rgba(color,125),rgba(color),2)
 if shape=='circle':dot(d,start,y,24,rgba(color,240),rgba('#FFFCF2'),3)
 else:
  d.polygon([(start,y-25),(start+25,y),(start,y+25),(start-25,y)],fill=rgba(color,235))
 text(d,(start+40,y),f'{midi} · hold for 4 seconds',21,PLUM,True,anchor='lm')
# 01 two voices
im=Image.new('RGBA',(W,H),(0,0,0,0));bar_header(im,'WEEK 2  /  LESSON 2A  /  STEP 2','Two notes. Two independent voices.','A dyad is two pitches together; each voice remains a line you can follow.')
put_art(im,(0,0,2172,350),(30,245,1370,445),.95);d=ImageDraw.Draw(im)
text(d,(76,458),'READ TWO SEPARATE LINES THROUGH TIME',19,ROSE,True)
flowline(d,555,250,1290,'E4','Upper voice',ORCHID,'diamond')
flowline(d,655,250,1290,'C4','Lower voice',SAGE,'circle')
line(d,[(250,715),(1290,715)],rgba('#AA98A6',190),2)
for xx,label in [(250,'0 s'),(510,'1 s'),(770,'2 s'),(1030,'3 s'),(1290,'4 s')]:
 line(d,[(xx,707),(xx,723)],rgba('#927789'),2);text(d,(xx,735),label,18,MUTED,anchor='mt')
rr(d,(72,800,1320,904),18,rgba('#FFF7F0',211),rgba('#B8A39D',85),2)
text(d,(103,819),'TRY IT ON YOUR OWN INSTRUMENT',18,ROSE,True)
text(d,(103,856),'Play C4 alone, E4 alone, then hold both for four slow counts.',23,PLUM)
im.save(ROOT/'assets'/'2A-01_two_independent_voices.desktop.png')
# 02 letters vs semitone steps
im=Image.new('RGBA',(W,H),(0,0,0,0));bar_header(im,'WEEK 2  /  LESSON 2A  /  STEPS 3–4','Two ways to measure C to E','The letter-name number and the exact keyboard distance answer different questions.')
put_art(im,(0,340,930,724),(55,208,650,355),.40);d=ImageDraw.Draw(im)
text(d,(80,239),'COUNT LETTER NAMES',20,ROSE,True)
for k,n in enumerate(['C','D','E']):
 x=170+k*174;dot(d,x,325,49,rgba('#F2D2A9',205),rgba('#BE8C56'),3);text(d,(x,325),n,40,PLUM,True,anchor='mm')
 if k<2:arrow(d,x+65,325,x+112,ROSE,4)
text(d,(190,399),'3 letter positions = a third',23,PLUM,True)
line(d,[(700,255),(700,430)],rgba('#BEB2B8'),2)
text(d,(750,239),'COUNT NEIGHBORING-KEY MOVES',19,ROSE,True)
for k,n in enumerate(['C4','C♯4','D4','D♯4','E4']):
 x=796+k*111;dot(d,x,325,35,rgba('#DED4E8',235),rgba(ORCHID),2);text(d,(x,325),n,19,PLUM,True,anchor='mm')
 if k<4:arrow(d,x+40,325,x+72,ORCHID,3)
text(d,(796,399),'4 moves = 4 semitones',23,PLUM,True)
text(d,(85,493),'ON A REAL KEYBOARD:  C4 → C♯4 → D4 → D♯4 → E4',21,MUTED,True)
piano(d,385,547,124,220,(60,64),GOLD)
rr(d,(84,815,1320,915),16,rgba('#FFF7F0',211),rgba('#B8A39D',95),2)
text(d,(110,837),'Remember: the starting key is zero. Count the moves, not the keys you touch.',22,PLUM,True)
im.save(ROOT/'assets'/'2A-02_letter_names_vs_semitone_moves.desktop.png')
# 03 major vs minor
im=Image.new('RGBA',(W,H),(0,0,0,0));bar_header(im,'WEEK 2  /  LESSON 2A  /  STEP 5','Two kinds of third','The letter span stays a third; the chromatic distance changes.')
put_art(im,(930,350,2172,724),(65,223,1325,380),.37);d=ImageDraw.Draw(im)
# independent columns with no huge filled backgrounds
rr(d,(67,285,675,812),28,rgba('#FCF7EE',114),rgba(GOLD,130),3)
rr(d,(725,285,1333,812),28,rgba('#FCF7EE',114),rgba(ORCHID,130),3)
text(d,(112,315),'MAJOR THIRD',22,GOLD,True);text(d,(770,315),'MINOR THIRD',22,ORCHID,True)
text(d,(112,363),'C4  →  E4',38,PLUM,True,True);text(d,(770,363),'E4  →  G4',38,PLUM,True,True)
text(d,(112,428),'4 semitones',27,GOLD,True);text(d,(770,428),'3 semitones',27,ORCHID,True)
piano(d,91,500,112,215,(60,64),GOLD)
piano(d,749,500,112,215,(64,67),ORCHID)
text(d,(118,748),'C4 → C♯4 → D4 → D♯4 → E4',19,MUTED)
text(d,(775,748),'E4 → F4 → F♯4 → G4',20,MUTED)
rr(d,(65,837,1335,919),18,rgba('#FFF7F0',205),rgba('#B8A39D',80),2)
text(d,(90,856),'TRY IT',17,ROSE,True)
text(d,(200,854),'Play each pair together, then as two notes in sequence. What changes?',22,PLUM)
im.save(ROOT/'assets'/'2A-03_major_vs_minor_third.desktop.png')
# phone reflow (rather than merely shrink): keep panels as a single vertical illustration at readable scale, based on high-quality desktop panels.
for n in ['2A-01_two_independent_voices','2A-02_letter_names_vs_semitone_moves','2A-03_major_vs_minor_third']:
 a=Image.open(ROOT/'assets'/f'{n}.desktop.png')
 # phone version split upper/lower for readability, do not resize all labels to 10px
 ph=Image.new('RGBA',(720,1100),(0,0,0,0))
 # contextual title redrawn at phone size for readability
 d=ImageDraw.Draw(ph)
 title={'2A-01_two_independent_voices':'Two independent voices','2A-02_letter_names_vs_semitone_moves':'Two ways to count','2A-03_major_vs_minor_third':'Major and minor thirds'}[n]
 text(d,(40,22),'AJOURNÉ  /  WEEK 2',18,ROSE,True);text(d,(40,65),title,37,PLUM,False,True)
 if n.endswith('voices'):
  put_art(ph,(0,0,2172,330),(15,160,700,325),.85)
  text(d,(45,353),'PLAY BOTH ON YOUR OWN KEYBOARD',20,ROSE,True)
  flowline(d,470,170,680,'E4','Upper',ORCHID,'diamond')
  flowline(d,600,170,680,'C4','Lower',SAGE,'circle')
  text(d,(55,716),'Both sound for 4 seconds.',25,PLUM,True)
  rr(d,(40,785,680,985),20,rgba('#FFF7F0',196),rgba('#B8A39D',84),2)
  text(d,(65,809),'PRACTICE',18,ROSE,True)
  for i,t in enumerate(['Play C4 by itself.','Play E4 by itself.','Now play and hold both.']):text(d,(65,851+i*39),t,23,PLUM)
 elif n.endswith('moves'):
  text(d,(45,159),'LETTER NAMES:  C · D · E',27,PLUM,True)
  text(d,(45,206),'3 positions = a third',23,GOLD,True)
  put_art(ph,(0,340,850,724),(50,250,660,358),.35)
  text(d,(45,368),'KEY MOVES:',20,ROSE,True)
  for i,t in enumerate(['0 C4','1 C♯4','2 D4','3 D♯4','4 E4']):
   x=70+i*129;dot(d,x,467,28,rgba('#EFE2DA',235),rgba(ORCHID),2)
   text(d,(x,467),t,15,PLUM,True,anchor='mm')
  text(d,(45,525),'4 semitone moves',25,ORCHID,True)
  piano(d,85,620,106,200,(60,64),GOLD)
  text(d,(45,873),'Start at zero; count each neighboring key.',22,PLUM)
 elif n.endswith('third'):
  text(d,(45,157),'Same letter distance. Different sizes.',22,MUTED)
  rr(d,(35,205,685,535),20,rgba('#F5EBD8',80),rgba(GOLD,130),2)
  text(d,(55,225),'MAJOR THIRD',20,GOLD,True);text(d,(55,265),'C4 to E4   ·   4 semitones',26,PLUM,True)
  piano(d,75,319,95,188,(60,64),GOLD)
  rr(d,(35,562,685,895),20,rgba('#EDE4F2',70),rgba(ORCHID,135),2)
  text(d,(55,583),'MINOR THIRD',20,ORCHID,True);text(d,(55,625),'E4 to G4   ·   3 semitones',26,PLUM,True)
  piano(d,75,676,95,190,(64,67),ORCHID)
  text(d,(45,934),'Play both pairs; listen to the change.',22,PLUM)
 ph.save(ROOT/'assets'/f'{n}.phone.png')
# metadata and source painterly fragments
import shutil
shutil.copy2('/mnt/data/a_clean_transparent_background_illustration_compos.png',ROOT/'source'/'imagegen_original_painterly_components.png')
shutil.copy2('/mnt/data/build_w2pilot.py',ROOT/'source'/'build_w2pilot.py')
files=[]
for p in sorted((ROOT/'assets').glob('*.png')):
 im=Image.open(p);corners=[im.getpixel((0,0))[3],im.getpixel((im.width-1,0))[3],im.getpixel((0,im.height-1))[3],im.getpixel((im.width-1,im.height-1))[3]]
 files.append({'file':str(p.relative_to(ROOT)),'size':im.size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cornersAlpha':corners})
manifest={'title':'Ajourné Week 2 Lesson 2A pilot - original painterly + source-driven musical infographics','status':'DRAFT FOR FOUNDER ART AND IN-LESSON REVIEW - NOT DEPLOYED','source':'Original ImageGen watercolor components + deterministic PIL musical diagrams built by ChatGPT; not Claude-generated artwork','images':files,'facts':{'C4_E4':{'midi':[60,64],'semitones':4,'name':'major third'},'E4_G4':{'midi':[64,67],'semitones':3,'name':'minor third'}},'notes':'Individual composite PNGs are transparent. A source Python file is supplied. Technical data is editable in source code, not hand-drawn watercolor. This artwork has NOT been QA tested inside the actual app and must not be deployed before founder approval.'}
(ROOT/'asset_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
(ROOT/'README.md').write_text('''# Ajourné Week 2 – Lesson 2A original visual pilot v1\n\n**Status: founder review only. Not yet approved or integrated.**\n\nThree original, information-bearing teaching graphics produced in ChatGPT using transparent ImageGen watercolor source art over exact programmatic music geometry. They correspond to 2A Step 2 (two independent voices), Steps 3-4 (letter positions vs semitone moves), and Step 5 (major/minor thirds). Desktop and phone-specific PNG compositions are included.\n\n**Caution:** This is a pilot, not a final art acceptance. Full rendered-page validation and comparison against Week 1 are still necessary. Art and accurate technical content are deliberately separable in `source/build_w2pilot.py`; the watercolor is not an editable vector diagram. No site audio.\n\nAccurate music data: C4 = MIDI 60, E4 = 64, G4 = 67; 4 and 3 semitones respectively. Label-based counts distinguish three positions C–D–E from four neighboring-key movements C–C♯–D–D♯–E. Transparent alpha corners verified in manifest.\n''')
# contact sheet
thumbs=[]
for n in ['2A-01_two_independent_voices','2A-02_letter_names_vs_semitone_moves','2A-03_major_vs_minor_third']:
 a=Image.open(ROOT/'assets'/f'{n}.desktop.png').convert('RGBA');bg=Image.new('RGBA',a.size,rgba('#F9F5ED'));bg.alpha_composite(a);bg=bg.convert('RGB');bg.thumbnail((1200,810));thumbs.append(bg)
sheet=Image.new('RGB',(1240,len(thumbs)*850),(235,224,221))
for k,im in enumerate(thumbs):sheet.paste(im,((1240-im.width)//2,k*850+10))
sheet.save(ROOT/'contact_desktop.jpg',quality=91)
zipname='/mnt/data/Ajourne_W2_2A_Original_Visual_Pilot_v1.zip'
with zipfile.ZipFile(zipname,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(ROOT.parent))
print('BUNDLE:',zipname,Path(zipname).stat().st_size,'bytes')
for f in files:print(f['file'],f['size'],f['cornersAlpha'])
