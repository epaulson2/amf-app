# Ajourné Week 2 – Lesson 2A original visual pilot v1

**Status: founder review only. Not yet approved or integrated.**

Three original, information-bearing teaching graphics produced in ChatGPT using transparent ImageGen watercolor source art over exact programmatic music geometry. They correspond to 2A Step 2 (two independent voices), Steps 3-4 (letter positions vs semitone moves), and Step 5 (major/minor thirds). Desktop and phone-specific PNG compositions are included.

**Caution:** This is a pilot, not a final art acceptance. Full rendered-page validation and comparison against Week 1 are still necessary. Art and accurate technical content are deliberately separable in `source/build_w2pilot.py`; the watercolor is not an editable vector diagram. No site audio.

Accurate music data: C4 = MIDI 60, E4 = 64, G4 = 67; 4 and 3 semitones respectively. Label-based counts distinguish three positions C–D–E from four neighboring-key movements C–C♯–D–D♯–E. Transparent alpha corners verified in manifest.
